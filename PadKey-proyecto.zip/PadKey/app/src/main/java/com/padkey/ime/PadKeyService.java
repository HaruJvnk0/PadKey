package com.padkey.ime;

import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

import java.util.HashSet;
import java.util.Set;

/**
 * Servicio del teclado (IME). Mientras el teclado esta visible, intercepta el
 * mando: stick izquierdo / cruceta mueven, A escribe, B borra, X espacio, etc.
 * Con el teclado oculto no toca nada: el mando vuelve a ser de la app.
 */
public class PadKeyService extends InputMethodService implements PadKeyboardView.Listener {

    private PadKeyboardView kb;
    private EditorInfo info;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Set<Integer> consumed = new HashSet<>();
    private int stickX, stickY;
    private long lastNav, lastCursor;

    private final Runnable stickRepeat = new Runnable() {
        @Override
        public void run() {
            if ((stickX != 0 || stickY != 0) && kb != null && isInputViewShown()) {
                kb.moveSel(stickX, stickY);
                handler.postDelayed(this, 110);
            }
        }
    };

    @Override
    public View onCreateInputView() {
        kb = new PadKeyboardView(this);
        kb.setListener(this);
        return kb;
    }

    /** Sin pantalla completa de texto en horizontal: el teclado ocupa poco. */
    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo attribute, boolean restarting) {
        super.onStartInputView(attribute, restarting);
        info = attribute;
        stopStick();
        int cls = attribute.inputType & InputType.TYPE_MASK_CLASS;
        boolean numeric = cls == InputType.TYPE_CLASS_NUMBER
                || cls == InputType.TYPE_CLASS_PHONE
                || cls == InputType.TYPE_CLASS_DATETIME;
        if (kb != null) kb.start(numeric, restarting);
        updateAutoCaps();
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        super.onFinishInputView(finishingInput);
        stopStick();
    }

    @Override
    public void onWindowHidden() {
        super.onWindowHidden();
        stopStick();
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                  int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd,
                candidatesStart, candidatesEnd);
        updateAutoCaps();
    }

    private void updateAutoCaps() {
        if (kb == null || info == null) return;
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        kb.setAutoShift(ic.getCursorCapsMode(info.inputType) != 0);
    }

    // ------------------------------------------------------------------
    // Salida de texto (la usa tanto el tactil como el mando)
    // ------------------------------------------------------------------

    @Override
    public void onText(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(s, 1);
    }

    @Override
    public void onBackspace() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
    }

    @Override
    public void onEnter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        int opts = info != null ? info.imeOptions : 0;
        int action = opts & EditorInfo.IME_MASK_ACTION;
        if ((opts & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0
                && action != EditorInfo.IME_ACTION_NONE
                && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action);
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        }
    }

    // ------------------------------------------------------------------
    // Mando
    // ------------------------------------------------------------------

    private static boolean fromPad(InputEvent e) {
        int s = e.getSource();
        return (s & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                || (s & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                || (s & InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (kb != null && isInputViewShown() && fromPad(event) && handlePadKey(keyCode, event)) {
            consumed.add(keyCode);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (consumed.remove(keyCode)) return true;
        return super.onKeyUp(keyCode, event);
    }

    private boolean handlePadKey(int code, KeyEvent e) {
        boolean first = e.getRepeatCount() == 0;
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                return nav(-1, 0, first);
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                return nav(1, 0, first);
            case KeyEvent.KEYCODE_DPAD_UP:
                return nav(0, -1, first);
            case KeyEvent.KEYCODE_DPAD_DOWN:
                return nav(0, 1, first);
            case KeyEvent.KEYCODE_BUTTON_A:
            case KeyEvent.KEYCODE_DPAD_CENTER:
                if (first) kb.pressSel();
                return true;
            case KeyEvent.KEYCODE_BUTTON_B:
                onBackspace();
                return true;
            case KeyEvent.KEYCODE_BUTTON_X:
                if (first) kb.padSpace();
                return true;
            case KeyEvent.KEYCODE_BUTTON_Y:
                if (first) kb.padShift();
                return true;
            case KeyEvent.KEYCODE_BUTTON_L1:
                cursor(KeyEvent.KEYCODE_DPAD_LEFT, first);
                return true;
            case KeyEvent.KEYCODE_BUTTON_R1:
                cursor(KeyEvent.KEYCODE_DPAD_RIGHT, first);
                return true;
            case KeyEvent.KEYCODE_BUTTON_THUMBL:
                if (first) kb.padPage();
                return true;
            case KeyEvent.KEYCODE_BUTTON_START:
                if (first) onEnter();
                return true;
            case KeyEvent.KEYCODE_BUTTON_SELECT:
                if (first) requestHideSelf(0);
                return true;
            default:
                return false;
        }
    }

    private boolean nav(int dx, int dy, boolean first) {
        long now = SystemClock.uptimeMillis();
        if (first || now - lastNav >= 90) {
            lastNav = now;
            kb.moveSel(dx, dy);
        }
        return true;
    }

    private void cursor(int keyCode, boolean first) {
        long now = SystemClock.uptimeMillis();
        if (first || now - lastCursor >= 70) {
            lastCursor = now;
            sendDownUpKeyEvents(keyCode);
        }
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        if (kb != null && isInputViewShown()
                && (e.getSource() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                && e.getActionMasked() == MotionEvent.ACTION_MOVE) {
            int dx = 0;
            int dy = 0;
            float hx = e.getAxisValue(MotionEvent.AXIS_HAT_X);
            float hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y);
            if (Math.abs(hx) > 0.5f) {
                dx = hx > 0f ? 1 : -1;
            } else if (Math.abs(hy) > 0.5f) {
                dy = hy > 0f ? 1 : -1;
            } else {
                float x = e.getAxisValue(MotionEvent.AXIS_X);
                float y = e.getAxisValue(MotionEvent.AXIS_Y);
                if (Math.abs(x) >= Math.abs(y)) dx = dir(x, stickX);
                else dy = dir(y, stickY);
            }
            stick(dx, dy);
            return true;
        }
        return super.onGenericMotionEvent(e);
    }

    /** Direccion de un eje con histeresis: entra pasando 0.6, sale bajando de 0.3. */
    private static int dir(float v, int current) {
        if (current != 0 && v * current > 0f && Math.abs(v) > 0.3f) return current;
        if (Math.abs(v) > 0.6f) return v > 0f ? 1 : -1;
        return 0;
    }

    private void stick(int dx, int dy) {
        if (dx == stickX && dy == stickY) return;
        stickX = dx;
        stickY = dy;
        handler.removeCallbacks(stickRepeat);
        if (dx != 0 || dy != 0) {
            kb.moveSel(dx, dy);
            handler.postDelayed(stickRepeat, 380);
        }
    }

    private void stopStick() {
        stickX = 0;
        stickY = 0;
        handler.removeCallbacks(stickRepeat);
    }
}
