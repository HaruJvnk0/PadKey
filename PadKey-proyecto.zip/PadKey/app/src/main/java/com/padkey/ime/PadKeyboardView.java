package com.padkey.ime;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.SparseArray;
import android.view.HapticFeedbackConstants;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Teclado dibujado a mano. Se usa con toque o con una seleccion que se mueve
 * con el mando (el servicio llama a moveSel / pressSel / padSpace / etc).
 */
public class PadKeyboardView extends View {

    public interface Listener {
        void onText(String s);
        void onBackspace();
        void onEnter();
    }

    private static final int CHAR = 0, SHIFT = 1, DEL = 2, SPACE = 3, ENTER = 4, PAGE = 5, ACCENT = 6;

    private static final class Key {
        final int type;
        final String label;
        final float w;
        float x0;
        final RectF r = new RectF();

        Key(int type, String label, float w) {
            this.type = type;
            this.label = label;
            this.w = w;
        }
    }

    private final List<List<List<Key>>> pages = new ArrayList<>();
    private final SparseArray<Key> down = new SparseArray<>();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint icon = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    private Listener listener;
    private int page, shift, accent, selRow = 1, selCol = 4;
    private float selCx = 4.5f;
    private boolean padActive, dirty = true, hapticOn = true;
    private float scale = 1f, opacity = 0.95f;
    private long lastShiftTap;
    private Key flash;
    private float boardLeft, boardUnit;
    private int bg, keyC, keyAlt, textC, accC;

    private final Runnable repeatDel = new Runnable() {
        @Override
        public void run() {
            if (listener != null) listener.onBackspace();
            postDelayed(this, 55);
        }
    };

    private final Runnable clearFlash = new Runnable() {
        @Override
        public void run() {
            flash = null;
            invalidate();
        }
    };

    public PadKeyboardView(Context ctx) {
        super(ctx);
        pages.add(place(letterRows()));
        pages.add(place(symbolRows()));
        text.setTextAlign(Paint.Align.CENTER);
        stroke.setStyle(Paint.Style.STROKE);
        icon.setStyle(Paint.Style.STROKE);
        icon.setStrokeCap(Paint.Cap.ROUND);
        icon.setStrokeJoin(Paint.Join.ROUND);
        loadTheme();
    }

    // ------------------------------------------------------------------
    // Disposicion de teclas (cada fila suma 10 unidades de ancho)
    // ------------------------------------------------------------------

    private static List<Key> chars(String spaced) {
        List<Key> out = new ArrayList<>();
        for (String s : spaced.split(" ")) out.add(new Key(CHAR, s, 1f));
        return out;
    }

    private static List<List<Key>> place(List<List<Key>> rows) {
        for (List<Key> row : rows) {
            float x = 0f;
            for (Key k : row) {
                k.x0 = x;
                x += k.w;
            }
        }
        return rows;
    }

    private static List<List<Key>> letterRows() {
        List<List<Key>> rows = new ArrayList<>();
        rows.add(chars("q w e r t y u i o p"));
        rows.add(chars("a s d f g h j k l \u00f1"));
        List<Key> r2 = new ArrayList<>();
        r2.add(new Key(SHIFT, "", 1.5f));
        r2.addAll(chars("z x c v b n m"));
        r2.add(new Key(DEL, "", 1.5f));
        rows.add(r2);
        List<Key> r3 = new ArrayList<>();
        r3.add(new Key(PAGE, "123", 1.5f));
        r3.add(new Key(ACCENT, "", 1f));
        r3.add(new Key(CHAR, ",", 1f));
        r3.add(new Key(SPACE, "", 3.5f));
        r3.add(new Key(CHAR, ".", 1f));
        r3.add(new Key(ENTER, "", 2f));
        rows.add(r3);
        return rows;
    }

    private static List<List<Key>> symbolRows() {
        List<List<Key>> rows = new ArrayList<>();
        rows.add(chars("1 2 3 4 5 6 7 8 9 0"));
        rows.add(chars("@ # $ \u20ac % & - _ ( )"));
        List<Key> r2 = new ArrayList<>(chars("* \" ' : ; ! ? \u00bf \u00a1"));
        r2.add(new Key(DEL, "", 1f));
        rows.add(r2);
        List<Key> r3 = new ArrayList<>();
        r3.add(new Key(PAGE, "ABC", 1.5f));
        r3.add(new Key(CHAR, "/", 1f));
        r3.add(new Key(CHAR, "+", 1f));
        r3.add(new Key(SPACE, "", 2.5f));
        r3.add(new Key(CHAR, ",", 1f));
        r3.add(new Key(CHAR, ".", 1f));
        r3.add(new Key(ENTER, "", 2f));
        rows.add(r3);
        return rows;
    }

    private List<List<Key>> rows() {
        return pages.get(page);
    }

    // ------------------------------------------------------------------
    // API para el servicio (mando)
    // ------------------------------------------------------------------

    public void setListener(Listener l) {
        listener = l;
    }

    /** Se llama cada vez que el teclado aparece en un campo de texto. */
    public void start(boolean numeric, boolean restarting) {
        loadPrefs();
        loadTheme();
        if (!restarting) {
            page = numeric ? 1 : 0;
            shift = 0;
            accent = 0;
            selRow = page == 0 ? 1 : 0;
            selCx = 4.5f;
            selCol = nearest(rows().get(selRow), selCx);
        }
        padActive = hasGamepad();
        dirty = true;
        invalidate();
    }

    /** Stick o cruceta: mueve la seleccion (con vuelta al otro lado). */
    public void moveSel(int dx, int dy) {
        padActive = true;
        List<List<Key>> rows = rows();
        if (dx != 0) {
            List<Key> row = rows.get(selRow);
            selCol = (selCol + dx + row.size()) % row.size();
            Key k = row.get(selCol);
            selCx = k.x0 + k.w / 2f;
        }
        if (dy != 0) {
            selRow = (selRow + dy + rows.size()) % rows.size();
            selCol = nearest(rows.get(selRow), selCx);
        }
        invalidate();
    }

    /** Boton A: escribe la tecla seleccionada. */
    public void pressSel() {
        if (!padActive) {
            // primera pulsacion despues de usar el tactil: solo muestra el cursor
            padActive = true;
            invalidate();
            return;
        }
        Key k = rows().get(selRow).get(selCol);
        hapticTap();
        flash = k;
        removeCallbacks(clearFlash);
        postDelayed(clearFlash, 110);
        press(k);
    }

    /** Boton X. */
    public void padSpace() {
        padActive = true;
        hapticTap();
        typeSpace();
        invalidate();
    }

    /** Boton Y. */
    public void padShift() {
        padActive = true;
        hapticTap();
        toggleShift();
    }

    /** Clic del stick izquierdo (L3): letras / numeros y simbolos. */
    public void padPage() {
        padActive = true;
        hapticTap();
        accent = 0;
        setPage(1 - page);
    }

    /** Mayuscula automatica al empezar frase (la calcula el servicio). */
    public void setAutoShift(boolean on) {
        if (shift == 2) return;
        int n = on ? 1 : 0;
        if (n != shift) {
            shift = n;
            invalidate();
        }
    }

    // ------------------------------------------------------------------
    // Logica de teclas
    // ------------------------------------------------------------------

    private void press(Key k) {
        switch (k.type) {
            case CHAR: {
                String s = k.label;
                if (page == 0 && Character.isLetter(s.charAt(0))) {
                    if (accent != 0) s = accented(s, accent);
                    if (shift != 0) s = s.toUpperCase(Locale.ROOT);
                }
                accent = 0;
                if (shift == 1) shift = 0;
                if (listener != null) listener.onText(s);
                break;
            }
            case SPACE:
                typeSpace();
                break;
            case DEL:
                if (listener != null) listener.onBackspace();
                break;
            case ENTER:
                if (listener != null) listener.onEnter();
                break;
            case SHIFT:
                toggleShift();
                break;
            case PAGE:
                accent = 0;
                setPage(1 - page);
                break;
            case ACCENT:
                accent = (accent + 1) % 3;
                break;
            default:
                break;
        }
        invalidate();
    }

    private void typeSpace() {
        accent = 0;
        if (listener != null) listener.onText(" ");
    }

    private void toggleShift() {
        long now = SystemClock.uptimeMillis();
        if (shift == 0) shift = 1;
        else if (shift == 1 && now - lastShiftTap < 450) shift = 2;
        else shift = 0;
        lastShiftTap = now;
        invalidate();
    }

    private void setPage(int p) {
        page = p;
        List<List<Key>> rows = rows();
        selRow = Math.min(selRow, rows.size() - 1);
        selCol = nearest(rows.get(selRow), selCx);
        dirty = true;
        invalidate();
    }

    private static String accented(String s, int mode) {
        if (mode == 1) {
            switch (s) {
                case "a": return "\u00e1";
                case "e": return "\u00e9";
                case "i": return "\u00ed";
                case "o": return "\u00f3";
                case "u": return "\u00fa";
                default: return s;
            }
        }
        return s.equals("u") ? "\u00fc" : s;
    }

    private int nearest(List<Key> row, float cx) {
        int best = 0;
        float bd = Float.MAX_VALUE;
        for (int i = 0; i < row.size(); i++) {
            Key k = row.get(i);
            float d = Math.abs(k.x0 + k.w / 2f - cx);
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    private void selectKey(Key k) {
        List<List<Key>> rows = rows();
        for (int r = 0; r < rows.size(); r++) {
            int i = rows.get(r).indexOf(k);
            if (i >= 0) {
                selRow = r;
                selCol = i;
                selCx = k.x0 + k.w / 2f;
                return;
            }
        }
    }

    private void hapticTap() {
        if (hapticOn) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private void loadPrefs() {
        SharedPreferences sp = getContext().getSharedPreferences("padkey", Context.MODE_PRIVATE);
        scale = sp.getInt("size", 100) / 100f;
        opacity = sp.getInt("opacity", 95) / 100f;
        hapticOn = sp.getBoolean("haptic", true);
        requestLayout();
    }

    private void loadTheme() {
        int night = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (night == Configuration.UI_MODE_NIGHT_YES) {
            bg = 0xFF16161A;
            keyC = 0xFF2C2C33;
            keyAlt = 0xFF3B3B44;
            textC = 0xFFF2F2F5;
            accC = 0xFF0AB9E6;
        } else {
            bg = 0xFFE4E5EA;
            keyC = 0xFFFFFFFF;
            keyAlt = 0xFFCFD1D8;
            textC = 0xFF1B1B1F;
            accC = 0xFF0AA5D6;
        }
    }

    private static boolean hasGamepad() {
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice d = InputDevice.getDevice(id);
            if (d == null) continue;
            int s = d.getSources();
            if ((s & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                    || (s & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------
    // Medidas y geometria
    // ------------------------------------------------------------------

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private boolean landscape() {
        return getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
    }

    private float keyH() {
        return dp(landscape() ? 34f : 42f) * scale;
    }

    private float padV() {
        return dp(6f);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        int height = Math.round(padV() * 2f + 4f * keyH() + 3f * dp(4f));
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        dirty = true;
    }

    private void layoutKeys() {
        int w = getWidth();
        float maxW = landscape() ? dp(640f) : Float.MAX_VALUE;
        float boardW = Math.min(w - dp(8f), maxW);
        boardLeft = (w - boardW) / 2f;
        boardUnit = boardW / 10f;
        float kh = keyH();
        float gap = dp(4f);
        float top = padV();
        List<List<Key>> rows = rows();
        for (int r = 0; r < rows.size(); r++) {
            float y = top + r * (kh + gap);
            for (Key k : rows.get(r)) {
                k.r.set(boardLeft + k.x0 * boardUnit + gap / 2f, y,
                        boardLeft + (k.x0 + k.w) * boardUnit - gap / 2f, y + kh);
            }
        }
        dirty = false;
    }

    private Key keyAt(float x, float y) {
        if (boardUnit <= 0f) return null;
        List<List<Key>> rows = rows();
        float kh = keyH();
        float gap = dp(4f);
        int r = (int) Math.floor((y - padV() + gap / 2f) / (kh + gap));
        r = Math.max(0, Math.min(rows.size() - 1, r));
        float u = (x - boardLeft) / boardUnit;
        if (u < -0.4f || u > 10.4f) return null;
        List<Key> row = rows.get(r);
        for (Key k : row) {
            if (u >= k.x0 && u < k.x0 + k.w) return k;
        }
        return u < 5f ? row.get(0) : row.get(row.size() - 1);
    }

    // ------------------------------------------------------------------
    // Dibujo
    // ------------------------------------------------------------------

    @Override
    protected void onDraw(Canvas c) {
        if (dirty) layoutKeys();
        fill.setColor((bg & 0x00FFFFFF) | (Math.round(opacity * 255f) << 24));
        c.drawRect(0f, 0f, getWidth(), getHeight(), fill);

        List<List<Key>> rows = rows();
        float rad = keyH() * 0.26f;
        float sw = dp(2.5f);
        for (int r = 0; r < rows.size(); r++) {
            List<Key> row = rows.get(r);
            for (int i = 0; i < row.size(); i++) {
                Key k = row.get(i);
                boolean sel = padActive && r == selRow && i == selCol;
                boolean pressed = k == flash || down.indexOfValue(k) >= 0;
                boolean on = (k.type == SHIFT && shift != 0) || (k.type == ACCENT && accent != 0);
                boolean special = k.type != CHAR && k.type != SPACE;

                fill.setColor(pressed ? accC : (special ? keyAlt : keyC));
                c.drawRoundRect(k.r, rad, rad, fill);
                if (on && !pressed) {
                    fill.setColor((accC & 0x00FFFFFF) | 0x55000000);
                    c.drawRoundRect(k.r, rad, rad, fill);
                }
                if (sel) {
                    fill.setColor((accC & 0x00FFFFFF) | 0x40000000);
                    c.drawRoundRect(k.r, rad, rad, fill);
                    stroke.setColor(accC);
                    stroke.setStrokeWidth(sw);
                    c.drawRoundRect(k.r.left + sw / 2f, k.r.top + sw / 2f,
                            k.r.right - sw / 2f, k.r.bottom - sw / 2f, rad, rad, stroke);
                }
                drawLabel(c, k);
            }
        }
    }

    private void drawLabel(Canvas c, Key k) {
        float cx = k.r.centerX();
        float cy = k.r.centerY();
        float s = Math.min(k.r.width(), k.r.height()) * 0.17f;
        switch (k.type) {
            case SHIFT:
            case DEL:
            case ENTER:
            case SPACE:
                drawIcon(c, k.type, cx, cy, s);
                break;
            case ACCENT:
                drawText(c, accent == 2 ? "\u00fc" : "\u00e1", cx, cy, keyH() * 0.44f);
                break;
            case PAGE:
                drawText(c, k.label, cx, cy, keyH() * 0.32f);
                break;
            default: {
                String t = k.label;
                if (page == 0 && shift != 0) t = t.toUpperCase(Locale.ROOT);
                drawText(c, t, cx, cy, keyH() * 0.44f);
                break;
            }
        }
    }

    private void drawText(Canvas c, String s, float cx, float cy, float size) {
        text.setColor(textC);
        text.setTextSize(size);
        c.drawText(s, cx, cy - (text.descent() + text.ascent()) / 2f, text);
    }

    private void drawIcon(Canvas c, int type, float cx, float cy, float s) {
        boolean on = type == SHIFT && shift != 0;
        icon.setColor(on ? accC : textC);
        icon.setStrokeWidth(s * 0.3f);
        icon.setStyle(Paint.Style.STROKE);
        path.reset();
        switch (type) {
            case SHIFT:
                path.moveTo(cx, cy - 1.5f * s);
                path.lineTo(cx + 1.5f * s, cy);
                path.lineTo(cx + 0.6f * s, cy);
                path.lineTo(cx + 0.6f * s, cy + 1.3f * s);
                path.lineTo(cx - 0.6f * s, cy + 1.3f * s);
                path.lineTo(cx - 0.6f * s, cy);
                path.lineTo(cx - 1.5f * s, cy);
                path.close();
                icon.setStyle(on ? Paint.Style.FILL_AND_STROKE : Paint.Style.STROKE);
                c.drawPath(path, icon);
                if (shift == 2) {
                    icon.setStyle(Paint.Style.STROKE);
                    c.drawLine(cx - 0.9f * s, cy + 2f * s, cx + 0.9f * s, cy + 2f * s, icon);
                }
                break;
            case DEL:
                path.moveTo(cx - 2f * s, cy);
                path.lineTo(cx - 0.8f * s, cy - 1.3f * s);
                path.lineTo(cx + 2f * s, cy - 1.3f * s);
                path.lineTo(cx + 2f * s, cy + 1.3f * s);
                path.lineTo(cx - 0.8f * s, cy + 1.3f * s);
                path.close();
                c.drawPath(path, icon);
                c.drawLine(cx - 0.2f * s, cy - 0.6f * s, cx + 1.2f * s, cy + 0.6f * s, icon);
                c.drawLine(cx - 0.2f * s, cy + 0.6f * s, cx + 1.2f * s, cy - 0.6f * s, icon);
                break;
            case ENTER:
                path.moveTo(cx + 1.7f * s, cy - 1.3f * s);
                path.lineTo(cx + 1.7f * s, cy + 0.3f * s);
                path.lineTo(cx - 1.5f * s, cy + 0.3f * s);
                c.drawPath(path, icon);
                path.reset();
                path.moveTo(cx - 0.5f * s, cy - 0.7f * s);
                path.lineTo(cx - 1.5f * s, cy + 0.3f * s);
                path.lineTo(cx - 0.5f * s, cy + 1.3f * s);
                c.drawPath(path, icon);
                break;
            case SPACE:
                path.moveTo(cx - 2.2f * s, cy - 0.4f * s);
                path.lineTo(cx - 2.2f * s, cy + 0.5f * s);
                path.lineTo(cx + 2.2f * s, cy + 0.5f * s);
                path.lineTo(cx + 2.2f * s, cy - 0.4f * s);
                c.drawPath(path, icon);
                break;
            default:
                break;
        }
    }

    // ------------------------------------------------------------------
    // Toque
    // ------------------------------------------------------------------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = e.getActionIndex();
                Key k = keyAt(e.getX(i), e.getY(i));
                if (k != null) {
                    padActive = false;
                    selectKey(k);
                    down.put(e.getPointerId(i), k);
                    hapticTap();
                    press(k);
                    if (k.type == DEL) {
                        removeCallbacks(repeatDel);
                        postDelayed(repeatDel, 420);
                    }
                    invalidate();
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                down.remove(e.getPointerId(e.getActionIndex()));
                boolean delHeld = false;
                for (int n = 0; n < down.size(); n++) {
                    if (down.valueAt(n).type == DEL) delHeld = true;
                }
                if (!delHeld) removeCallbacks(repeatDel);
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                down.clear();
                removeCallbacks(repeatDel);
                invalidate();
                return true;
            default:
                return true;
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(repeatDel);
        removeCallbacks(clearFlash);
        super.onDetachedFromWindow();
    }
}
