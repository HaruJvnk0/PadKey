package com.padkey.ime;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class SettingsActivity extends Activity {

    private static final String HELP =
            "Stick izquierdo / cruceta: mover la selecci\u00f3n\n"
            + "A: escribir la tecla seleccionada\n"
            + "B: borrar (mant\u00e9n pulsado para repetir)\n"
            + "X: espacio\n"
            + "Y: may\u00fascula (dos veces seguidas: bloquear)\n"
            + "L1 / R1: mover el cursor del texto\n"
            + "L3 (clic del stick izquierdo): letras / n\u00fameros y s\u00edmbolos\n"
            + "Start: Enter o acci\u00f3n del campo\n"
            + "Select: cerrar el teclado\n\n"
            + "Tecla \u00e1: p\u00falsala y luego una vocal para acentuar "
            + "(dos veces: di\u00e9resis, \u00fc).";

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("padkey", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(28));

        root.addView(label("PadKey", 28, true));
        root.addView(label("Teclado para usar con mando (y tambi\u00e9n t\u00e1ctil).", 15, false));

        root.addView(label("Instalaci\u00f3n", 18, true));
        root.addView(button("1. Activar PadKey", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        }));
        root.addView(button("2. Elegir PadKey como teclado", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        }));

        EditText test = new EditText(this);
        test.setHint("Escribe aqu\u00ed para probar");
        root.addView(test);

        root.addView(label("Ajustes", 18, true));
        slider(root, "Tama\u00f1o del teclado", "size", 70, 130, 100);
        slider(root, "Opacidad del fondo", "opacity", 30, 100, 95);

        CheckBox haptic = new CheckBox(this);
        haptic.setText("Vibraci\u00f3n al pulsar");
        haptic.setChecked(prefs.getBoolean("haptic", true));
        haptic.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                prefs.edit().putBoolean("haptic", on).apply();
            }
        });
        root.addView(haptic);

        root.addView(label("Controles con mando", 18, true));
        root.addView(label(HELP, 15, false));

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView label(String s, float size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setPadding(0, dp(10), 0, dp(4));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private void slider(LinearLayout root, String title, final String key,
                        final int min, int max, int def) {
        root.addView(label(title, 14, false));
        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(prefs.getInt(key, def) - min);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                prefs.edit().putInt(key, progress + min).apply();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        root.addView(bar);
    }
}
